<?php

include "dsn.php";

$pdo_sql = "TRUNCATE TABLE catm";
$pdo->prepare($pdo_sql)->execute();
$pdo_sql = "TRUNCATE TABLE catb";
$pdo->prepare($pdo_sql)->execute();

require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;

$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
$spreadsheet = $reader->load("test.xlsx");

$sheetData = $spreadsheet->getActiveSheet()->toArray();

$i_ar = [];
$i_ar_reg = 0;

$i = 1;

$main_kod = '';

unset($sheetData[0]);

foreach($sheetData as $t){

    $i_ar_reg = 0;
    foreach($i_ar as $i_ar_item){
        if($t[5] == $i_ar_item){
            $i_ar_reg = 1;
        }
    }

    if($i_ar_reg == 0){
        if($t[5] != "Не определено"){
            array_push($i_ar, $t[5]);

            $pdo_sql = "INSERT INTO catm (catm_name, sort) VALUES (?,?)";
            $pdo->prepare($pdo_sql)->execute([$t[5], $i]);

            $pdo_query = $pdo->prepare("SELECT MAX(catm.kod_catm) FROM catm;");
            $pdo_query->execute();
            while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){
                $main_kod = reset($pdo_row);
            }

            $i++;

        }
    }elseif($i_ar_reg == 1){
        $pdo_query = $pdo->prepare("SELECT catm.kod_catm FROM catm WHERE (((catm.catm_name)=?))");
        $pdo_query->execute([$t[5]]);
        while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){
            $main_kod = reset($pdo_row);
        }
    }

    if($main_kod != ''){
        $pdo_sql = "INSERT INTO catb (kod_catm, catb_name, catb_code, catb_article, catb_brand, catb_desc1, catb_desc2, catb_etim, catb_other) VALUES (?,?,?,?,?,?,?,?,?)";
        $pdo->prepare($pdo_sql)->execute([$main_kod, $t[1], $t[0], $t[3], $t[4], $t[5], $t[6], $t[9], $t[10]]);
    }else{
        echo 'Error Main Kod'.'<br>';
    }

}

?>