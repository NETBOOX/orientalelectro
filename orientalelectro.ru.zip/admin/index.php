<?php

if(!file_exists('../php/connect.x')){
	include 'page/_access.hx';
}else{
	$dsn_file = explode(",", file_get_contents('../php/connect.x', true));
	$dsn_host = $dsn_file[0];
	$dsn_user = $dsn_file[1];
	$dsn_pass = $dsn_file[2];
	$dsn_db   = $dsn_file[3];

	$dsn = "mysql:host=$dsn_host;dbname=$dsn_db;charset=utf8";
	$dsn_opt = [
	    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
	    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
	    PDO::ATTR_EMULATE_PREPARES   => false,
	];
	$pdo = new PDO($dsn, $dsn_user, $dsn_pass, $dsn_opt);

	if(!isset($_COOKIE["_access_hx"])){
		include 'page/login.hx';
	}else{
		$_hx = explode("#", base64_decode($_COOKIE["_access_hx"]));

		if(count($_hx) == 2){
			$pdo_query = $pdo->prepare("SELECT access.kod_access FROM access WHERE (((access.user)=?) AND ((access.pass)=?)) LIMIT 1");
			$pdo_query->execute([$_hx[0], $_hx[1]]);
			$pdo_array = $pdo_query->fetch(PDO::FETCH_ASSOC);

			if(!$pdo_array){
				include 'page/login.hx';
			}else{
				include 'page/cab.hx';
			}
		}else{
			include 'page/login.hx';
		}
	}
}

?>