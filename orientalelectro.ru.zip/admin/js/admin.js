function _select_option(_select_option_config_tmp){
    var _select_option_config = _select_option_config_tmp.split("#");

    $.ajax({
        type: 'POST',
        url: 'php/_select_option.php',
        data: {'_select_option_config': _select_option_config_tmp},
        dataType: 'text',
        success: function(text){
            document.getElementById(_select_option_config[1]).innerHTML = text;
        }
    }); 
}

// Insert Function
// [0] Prompt Text
// [1] Prefix
// [2] Parent Prefix
// [3] Parent Kod
// [4] Sort

var _insert_config = [];

var _insert_prompt = '';
var _insert_prefix = '';
var _insert_parent_prefix = '';
var _insert_parent_kod = '';
var _insert_sort = '';

var _insert_value = '';

function _insert(_insert_config_tmp){
	_insert_value = '';
	_insert_config.length = 0;
	_insert_config = _insert_config_tmp.split("#");

	_insert_prompt = _insert_config[0];
	_insert_prefix = _insert_config[1];
	_insert_parent_prefix = _insert_config[2];
	_insert_parent_kod = _insert_config[3];

    _insert_date = '';
    if(_insert_config.length > 4){
        _insert_date = _insert_config[4];
    }

	_insert_sort = _sort_kod_main.length + 1;
	_insert_value = injection(prompt(_insert_prompt, ''));    

	if(_insert_value){
		$.ajax({
			type: 'POST',
			url: 'php/_insert.php',
			data: {'_insert_config': _insert_config_tmp, '_insert_value': _insert_value, '_insert_sort': _insert_sort},
			dataType: 'text',
			success: function(text){
				eval(_insert_prefix + "_select_one('" + text + "')");
			}
		}); 
	}
}

//Delete Function
function _delete(_delete_config_tmp, _delete_prefix_tmp, _delete_kod_tmp, _delete_name_tmp, _delete_confirm_tmp){
    if(confirm("Удалить " + _delete_confirm_tmp + "?")){
        $.ajax({
            type: 'POST',
            url: 'php/_delete.php',
            data: {'_delete_config': _delete_config_tmp},
            dataType: 'text',
            success: function(text){
                eval(_delete_prefix_tmp + "_select('" + _delete_kod_tmp + "', '" + _delete_name_tmp + "')");
            }
        }); 
    }
}

//Sort Function
var _sort_prefix = '';
var _sort_id_tmp = [];
var _sort_kod_tmp = [];

function _sort(_sort_list_tmp, _sort_prefix_tmp){
    var _sort_id = 1;
    _sort_id_tmp.length = 0;
    _sort_kod_tmp.length = 0;

    _sort_ar = _sort_list_tmp.split(',');
    for(var i = 0; i < _sort_ar.length; i++){
        for(var y = 0; y < _sort_id_main.length; y++){
            if(_sort_ar[i] == _sort_id_main[y]){
               _sort_id_tmp.push(_sort_id);
               _sort_kod_tmp.push(_sort_kod_main[y]);
               _sort_id += 1;
            }       
        }
    }

    var _sort_st = "";    
    for(var y = 0; y < _sort_id_main.length; y++){
        if(y == _sort_id_main.length - 1){
            _sort_st += _sort_id_tmp[y] + "," + _sort_kod_tmp[y];
        }else{
            _sort_st += _sort_id_tmp[y] + "," + _sort_kod_tmp[y] + ",";
        }
    }

    $.ajax({
        type: 'POST',
        url: 'php/_sort.php',
        data: {'_sort': _sort_st, '_prefix': _sort_prefix_tmp},
        dataType: 'text',
        success: function(text){
        }
    }); 
}

//File Upload
var _file_config = [];
var _file_config_st = '';

function _file_add(){
	document.getElementById("i_file_upload").innerHTML = document.getElementById("i_file_upload").innerHTML;
	document.getElementById("_file_upload").click(); 
}

function _file_upload_in(){
    document.nameupload0.myupload0.click();
    document.getElementById("id_load_data").style.display = "block";
}

function _file_uploaded(){
    document.getElementById("id_load_data").style.display = "none";
    alert('Импорт данных завершен!');
}

function _file_uploaded_error(){
    document.getElementById("id_load_data").style.display = "none";
    alert('Ошибка импорта данных!');
}

function _file_select(_file_select_path_tmp, _file_select_kod_tmp, _file_select_ext_tmp, _file_select_view_tmp, _file_select_prefix_tmp){
    $.ajax({
        type: 'POST',
        url: 'php/_file_select.php',
        data: {'_path': _file_select_path_tmp, '_kod': _main_kod, '_ext': _file_select_ext_tmp, '_view': _file_select_view_tmp, '_prefix': _file_select_prefix_tmp},
        dataType: 'text',
        success: function(text){
            document.getElementById("i_" + _file_select_prefix_tmp + "_file").innerHTML = text;
        }
    }); 
}

function _file_main(_file_main_path_tmp, _file_main_kod_tmp, _file_main_file_tmp, _file_main_prefix_tmp){
    $.ajax({
        type: 'POST',
        url: 'php/_file_main.php',
        data: {'_path': _file_main_path_tmp, '_kod': _file_main_kod_tmp, '_file': _file_main_file_tmp, '_prefix': _file_main_prefix_tmp},
        dataType: 'text',
        success: function(text){
            //eval(_file_main_prefix_tmp + "_file_select()");
            _file_select(_file_main_prefix_tmp, _file_main_kod_tmp, '', '0', _file_main_prefix_tmp);
        }
    });
}

function _file_delete(_file_delete_path_tmp, _file_delete_prefix_tmp){
    var _file_kod_path = _file_delete_path_tmp.replace("../files/" + _file_delete_prefix_tmp + '/', '');
    var _file_kod_ar = _file_kod_path.split('/');

    if(confirm("Удалить файл?")){
        $.ajax({
            type: 'POST',
            url: 'php/_file_delete.php',
            data: {'_file': _file_delete_path_tmp},
            dataType: 'text',
            success: function(text){
                _file_select(_file_delete_prefix_tmp, _file_kod_ar[0], '', '0', _file_delete_prefix_tmp);
            }
        });
    }
}
