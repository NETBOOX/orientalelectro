var _sort_kod_main = [];
var _sort_id_main = [];

var _main_kod = '';
var _main_name = '';
var _main_parent_kod = '';
var _main_parent_name = '';
var _main_parent_kod_x = '';
var _main_parent_name_x = '';
var _main_parent_prefix = '';

var _update_field = '';
var _update_value = '';

var _empty = '<div>Не найдено</div>';


var sp_post_before = [];
var sp_post = [];
var sp_post_date = [];
var sp_post_go = 0;
var sp_st = "";

var org_type = '';

function load_manager(){
    clock();
}
document.addEventListener( "DOMContentLoaded", load_manager, false );

$(document).ready(function(){
    $(".bl").on("click", function(event){
        $(".bl").removeClass("active");
        $("#i_bl" + $(this).attr('id').replace("i_bl","")).addClass("active");
        $(".bd").removeClass("active");
        $("#i_bd" + $(this).attr('id').replace("i_bl","")).addClass("active");

        var menu_ind = $(this).attr('id').replace("i_bl","");

        if(menu_ind == '1'){
            pod_select();
        }
    });

    $('._sortable').sortable({
        axis: 'y',
        opacity: 0.6,
        stop: function(){
            var _sortable_list = $('._sortable').sortable("toArray").toString();
            var _sortable_prefix = $('._sortable').attr("id").replace('edit_', '');
            _sort(_sortable_list, _sortable_prefix);
        }    
    });

}); 

function user_exit(){
	if(confirm("Выйти из личного кабинета?")){
		delete_cookie('_access_hx');
		location.reload();
	}
}

function clock(){
    var date = new Date(),
    hours = (date.getHours() < 10) ? '0' + date.getHours() : date.getHours(),
    minutes = (date.getMinutes() < 10) ? '0' + date.getMinutes() : date.getMinutes(),
    seconds = (date.getSeconds() < 10) ? '0' + date.getSeconds() : date.getSeconds();
    document.getElementById('clock').innerHTML = hours + ':' + minutes + ':' + seconds;
}
setInterval(clock, 1000);

var main_menu_show = '';

function menu_show(menu_show_tmp){
    if(main_menu_show == ''){
        main_menu_show = menu_show_tmp;
        $(".edit_menu").removeClass("show");
        $("#i_edit_menu_" + main_menu_show).addClass("show");
    }else{
        if(main_menu_show != menu_show_tmp){
            main_menu_show = menu_show_tmp;
            $(".edit_menu").removeClass("show");
            $("#i_edit_menu_" + main_menu_show).addClass("show");
        }else{
            if($("#i_edit_menu_" + menu_show_tmp).hasClass("show") == false){
                $("#i_edit_menu_" + menu_show_tmp).addClass("show");
            }else{
                $("#i_edit_menu_" + menu_show_tmp).removeClass("show");
            }
        }
    }
}








//pod Function-------------------------------------------------------------------
var _const_pod_bd = '1';
var _const_pod_prefix = 'pod';
var _const_pod_parent_prefix = '';
var _const_pod_file_prefix = '.jpg,.png,.webp';
var _const_pod_sort = '';
var _const_pod_function = [];
var _const_pod_notification = ['подсказки', 'подсказку']; //Insert, Delete


function pod_select(pod_select_parent_kod_tmp = '', pod_select_parent_name_tmp = ''){   
$('.bd_d').removeClass('active');
$('#i_bd' + _const_pod_bd).addClass('active');
$('#i_bd' + _const_pod_bd + '_0').addClass('active');

document.getElementById('edit_' + _const_pod_prefix).innerHTML = 'Загрузка...'; 

sp_post.length = 0;
sp_post_before.length = 0;
sp_st = '';

_main_parent_kod = pod_select_parent_kod_tmp;
_main_parent_name = pod_select_parent_name_tmp;

_sort_kod_main.length = 0;
_sort_id_main.length = 0;

    $.ajax({
        type: 'POST',
        url: 'php/_select.php',
        data: {'_select_prefix': _const_pod_prefix, '_select_sort': '', '_select_parent_prefix': _const_pod_parent_prefix, '_select_parent_kod': _main_parent_kod},
        dataType: 'text',
        success: function(text){
            sp_post_before = text.split('{divide}');
            sp_post = sp_post_before[1].split('#');
            
            for(var i = 0; i < sp_post.length-1; i += parseInt(sp_post_before[0])){
                _sort_kod_main.push(sp_post[i]);
                _sort_id_main.push(sp_post[i+1]);

                sp_st += '<li id="' + sp_post[i+1] +'">';
                    sp_st += '<div class="edit_name"><i class="bi bi-stop-fill"></i> ' + sp_post[i+4] + '</div>';
                    sp_st += '<div class="edit_btn" onClick="' + _const_pod_prefix + '_select_one(\'' + sp_post[i] + '\',\'' + sp_post[i+4] + '\');">Редактировать</div>';

                    sp_st += '<span id="i_edit_menu_' + _const_pod_prefix + sp_post[i] + '" class="edit_menu" onClick="menu_show(\'' + _const_pod_prefix + sp_post[i] + '\');">';
                        sp_st += '<img src="images/svg/i_menu.svg">';
                        sp_st += '<ul class="edit_menu_list">';
                            sp_st += '<li onClick="' + _const_pod_prefix + '_select_one(\'' + sp_post[i] + '\',\'' + sp_post[i+4] + '\');">Редактировать</li>';
                            sp_st += '<li onClick="' + _const_pod_prefix + '_delete(\'' + sp_post[i] + '\',\'' + sp_post[i+4] + '\');">Удалить</li>';
                        sp_st += '</ul>';
                    sp_st += '</span>';

                sp_st += '</li>';
            }

            if(sp_st == ''){
                document.getElementById('edit_' + _const_pod_prefix).innerHTML = _empty;
            }else{
                document.getElementById('edit_' + _const_pod_prefix).innerHTML = sp_st;
            } 
        }
    }); 
}

function pod_insert(){
    _insert('Введите название ' + _const_pod_notification[0] + '#' + _const_pod_prefix + '#' + _const_pod_parent_prefix + '#' + _main_parent_kod);     
}

function pod_select_one(pod_select_one_kod_tmp){
_main_kod = pod_select_one_kod_tmp;
_main_name = '';

$('.bd_d').removeClass('active');
$('#i_bd' + _const_pod_bd + '_0_1').addClass('active');

sp_post.length = 0;

    $.ajax({
        type: 'POST',
        url: 'php/_select_one.php',
        data: {'_select_prefix': _const_pod_prefix, '_select_kod': _main_kod},
        dataType: 'text',
        success: function(text){
            sp_post = text.split('#');

            document.getElementById('i_' + _const_pod_prefix).innerText = sp_post[4];
            document.getElementById('i_' + _const_pod_prefix + '_name').value = sp_post[4];
            document.getElementById('i_' + _const_pod_prefix + '_value').value = sp_post[5];
        }
    });    
}

function pod_update(){
    _update_field = '';
    _update_value = '';

    _update_field += _const_pod_prefix + '_name';
    _update_value += injection(document.getElementById('i_' + _const_pod_prefix + '_name').value);

    _update_field += '#' + _const_pod_prefix + '_value';
    _update_value += '#' + injection(document.getElementById('i_' + _const_pod_prefix + '_value').value);

    _update_field = Base64.encode(_update_field);
    _update_value = Base64.encode(_update_value);

    if(document.getElementById('i_' + _const_pod_prefix + '_name').value != ''){
        $.ajax({
            type: 'POST',
            url: 'php/_update.php',
            data: {'_update_prefix': _const_pod_prefix, '_update_kod': _main_kod, '_update_field': _update_field, '_update_value': _update_value},
            dataType: 'text',
            success: function(text){
                pod_select(_main_parent_kod, _main_parent_name);
            }
        });
    }else{
        alert('Введите название ' + _const_pod_notification[0]);
    } 
}

function pod_delete(pod_delete_kod_tmp, pod_delete_name_tmp){
    _delete(_const_pod_prefix + '#' + pod_delete_kod_tmp + '#' + _const_pod_prefix + '###', _const_pod_prefix, _main_parent_kod, _main_parent_name, _const_pod_notification[0] + ' - ' + pod_delete_name_tmp);  
}

//END pod Function-------------------------------------------------------------------































function popup_open(popup_show_tmp){
    $(".in_popup").removeClass("active");
    $("#i_in_popup" + popup_show_tmp).addClass("active");    
}

function popup_close(){
    $(".in_popup").removeClass("active"); 
}