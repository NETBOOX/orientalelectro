function load_manager(){

}
document.addEventListener( "DOMContentLoaded", load_manager, false );

function write_cookie(name,value,days){
    if (days) {
            var date = new Date();
            date.setTime(date.getTime()+(days*24*60*60*1000));
            var expires = "; expires="+date.toGMTString();
    }
    else var expires = "";
    document.cookie = name+"="+escape(value)+expires+"; path=/";
}

function user_go(){
	var lk_name = document.getElementById("lk_name").value;
	var lk_password = document.getElementById("lk_password").value;
	var lk_cookie = Base64.encode(lk_name + "#" + lk_password);
	write_cookie('_access_hx',lk_cookie,'300');
	location.reload();
}

function lk1(lk1_tmp){
    if(lk1_tmp == '0'){
        document.getElementById("lk_name").readOnly = true;
    }else{
        document.getElementById("lk_name").readOnly = false;
    }
}

function lk2(lk2_tmp){
    if(lk2_tmp == '0'){
        document.getElementById("lk_password").readOnly = true;
    }else{
        document.getElementById("lk_password").readOnly = false;
    }
}