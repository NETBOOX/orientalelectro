<?php

include "dsn.php";

for($i = 1; $i <= 18; $i++){
	$res = file_get_contents($i); 

	if($res != ''){
		$lines = explode("\r\n", $res);

		for($y = 0; $y <= COUNT($lines)-1; $y += 10){

			$pdo_sql = "INSERT INTO ti (kod_tires, ti_name, ti_part, ti_size, ti_over, ti_ply, 	ti_sec, ti_rim, ti_max, ti_max1, ti_pos) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
			$pdo->prepare($pdo_sql)->execute([$i, str_replace("---", "", $lines[$y]), $lines[$y+1], $lines[$y+2], $lines[$y+3], $lines[$y+4], $lines[$y+5], $lines[$y+6], $lines[$y+7], $lines[$y+8], $lines[$y+9]]);
		}
	}
}

?>