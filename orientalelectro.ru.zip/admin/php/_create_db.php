<?php

$_db_name = $_POST['_db_name'];
$_sv_host = $_POST['_sv_host'];
$_sv_login = $_POST['_sv_login'];
$_sv_password = $_POST['_sv_password'];

$servername = $_sv_host;
$username = $_sv_login;
$password = $_sv_password;

try {
    $conn = new PDO("mysql:host=$servername", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "CREATE DATABASE ".$_db_name." CHARACTER SET utf8 COLLATE utf8_general_ci";
    $conn->exec($sql);

    $conn = new PDO("mysql:host=$servername;dbname=".$_db_name, $username, $password);
    $sql = "CREATE TABLE access (kod_access INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, user VARCHAR(30) NOT NULL, pass VARCHAR(30) NOT NULL)";
    $conn->exec($sql);

    $sql = "INSERT INTO access (user, pass) VALUES (?,?)";
    $conn->prepare($sql)->execute(['admin', '12345']);    

    if(!file_exists('../../php/')){
        mkdir('../../php/', 0777, true);
    }

    file_put_contents('../../php/connect.x', 'localhost,root,,'.$_db_name);
} catch(PDOException $e) {
    echo $sql . "<br>" . $e->getMessage();
}

$conn = null;

?>