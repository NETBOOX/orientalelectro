<?php

$const_token = '0f041e014f9afcfc7385aea9f8b56ad25adbcf5b';
$const_secret = 'd517ae038df69e749880a394ecbff92143c9b6c6';
$url = 'https://suggestions.dadata.ru/suggestions/api/4_1/rs/findById/bank';

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$headers = array(
   "Content-Type: application/json",
   "Accept: application/json",
   "Authorization: Token ".$const_token,
);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
$data = '{ "query": "'.$_POST['bank_bik'].'" }';
curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
$resp = curl_exec($curl);
curl_close($curl);
$json_company = json_decode($resp, true);

$r_text = '';

if($resp != '{"suggestions":[]}'){
    $r_text .= $json_company['suggestions'][0]['value'].'#';
    $r_text .= $json_company['suggestions'][0]['data']['correspondent_account'].'#';
}

echo $r_text;

?>
