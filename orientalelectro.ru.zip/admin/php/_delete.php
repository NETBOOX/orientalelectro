<?php

include "dsn.php";

$_delete_config = explode("#", $_POST['_delete_config']);

$_prefix = $_delete_config[0];
$_prefix_kod = $_delete_config[1];
$_prefix_path = $_delete_config[2];
$_prefix_child = explode(",", $_delete_config[3]);
$_prefix_child_path = explode(",", $_delete_config[4]);

if($_delete_config[3] != ''){
	if(COUNT($_prefix_child) == 1){	
		if($_prefix_child_path[0] != ''){
			$pdo_query = $pdo->prepare("SELECT ".$_prefix_child[0].".kod_".$_prefix_child[0]." FROM ".$_prefix_child[0]." WHERE (((".$_prefix_child[0].".kod_".$_prefix.")=?))");
			$pdo_query->execute([$_prefix_kod]);
			while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){
				if(file_exists("../../files/".$_prefix_child_path[0]."/".$pdo_row['kod_'.$_prefix_child[0]]."/")){
				   removeDirectory("../../files/".$_prefix_child_path[0]."/".$pdo_row['kod_'.$_prefix_child[0]]."/");
				}			
			}
		}

		$pdo_sql = 'DELETE FROM '.$_prefix_child[0].' WHERE kod_'.$_prefix.'=?';
		$pdo->prepare($pdo_sql)->execute([$_prefix_kod]);
	}
}

if($_prefix_path != ''){
	if(file_exists("../../files/".$_prefix_path."/".$_prefix_kod."/")){
		removeDirectory("../../files/".$_prefix_path."/".$_prefix_kod."/");
	}
}

$pdo_sql = 'DELETE FROM '.$_prefix.' WHERE kod_'.$_prefix.'=?';
$pdo->prepare($pdo_sql)->execute([$_prefix_kod]);



function removeDirectory($dir) {
	if($objs = glob($dir."/*")){
	   foreach($objs as $obj) {
	     is_dir($obj) ? removeDirectory($obj) : unlink($obj);
	   }
	}
	rmdir($dir);
}

?>
