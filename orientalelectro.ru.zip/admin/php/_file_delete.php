<?php

$_file = $_POST['_file'];
$_file = '../'.$_file;

if(file_exists($_file)){
   unlink($_file);
}

?>