<?php

$_path = $_POST['_path'];
$_kod = $_POST['_kod'];
$_file = $_POST['_file'];
$_prefix = $_POST['_prefix'];

$_dir = '../../files/'.$_path.'/'.$_kod.'/';

if(file_exists($_dir)){
    $result = array();
    $cdir = scandir($_dir); 
    foreach ($cdir as $value) {
        if (!in_array($value,array(".", "..")) && !is_dir($_dir . DIRECTORY_SEPARATOR . $value)){
            $result[] = $value;
        }
    }

    foreach($result as &$result_value){
        rename($_dir.$result_value, $_dir.str_replace("@","",$result_value));   
    }
    rename($_dir.$_file, $_dir.'@'.$_file);
}

?>