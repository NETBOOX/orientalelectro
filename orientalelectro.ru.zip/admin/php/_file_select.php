<?php

$_path = $_POST['_path'];
$_kod = $_POST['_kod'];
$_ext = $_POST['_ext'];
$_view = $_POST['_view'];
$_prefix = $_POST['_prefix'];

$_html = '';
$_file = '';

$_dir = '../../files/'.$_path.'/'.$_kod.'/';

if(file_exists($_dir)){
    $result = array();
    $cdir = scandir($_dir); 
    foreach ($cdir as $value) {
        if (!in_array($value,array(".", "..")) && !is_dir($_dir . DIRECTORY_SEPARATOR . $value)){
            $ext = pathinfo($value, PATHINFO_EXTENSION);

            if($_ext != ''){
                if($_ext == $ext){
                    $result[] = $value;
                }
            }else{
                $result[] = $value;
            }
         }
    }

    foreach ($result as &$result_value) {
        if($_view == '0'){
            $_file = '../files/'.$_path.'/'.$_kod.'/'.$result_value;

            $_html .= '<div style="position: relative; display: inline-block; margin-right: 15px;">';

                $ext = pathinfo($result_value, PATHINFO_EXTENSION);

                if($ext == 'webp' || $ext == 'jpg' || $ext == 'jpeg' || $ext == 'png'){
                    $_html .= '<img class="photo_item_img" src="'.$_file.'">';

                    if(COUNT($result) > 0){
                        if(substr($result_value, 0, 1) == '@'){
                            $_html .= '<div class="photo_item_img_delete">Главное</div>';
                        }else{
                            $_html .= '<div class="photo_item_img_delete" onClick="_file_main(\''.$_path.'\', \''.$_kod.'\', \''.$result_value.'\', \''.$_prefix.'\');">Сделать главным</div>';
                        }
                    }
                }elseif($ext == 'dox'){
                    $_html .= '<img class="photo_item_img" src="images/dox.svg">';
                    $_html .= '<div class="photo_item_img_delete" onClick="_file_main(\''.$_path.'\', \''.$_kod.'\', \''.$result_value.'\', \''.$_prefix.'\');">Редактировать</div>';
                }

                $_html .= '<div class="photo_item_img_delete" onClick="'.$_prefix.'_file_delete(\''.$_file.'\');">Удалить</div>';
            $_html .= '</div>';
        }
    }

    if($_html == ''){
        $_html = 'Не найдено';
        echo $_html;
    }else{
        echo $_html;
    }
}else{
    echo 'Не найдено';
}

?>