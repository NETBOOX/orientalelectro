﻿<?php

include "dsn.php";

$_insert_config = explode("#", $_POST['_insert_config']);
$_insert_value = $_POST['_insert_value'];
$_insert_sort = $_POST['_insert_sort'];

if(COUNT($_insert_config) > 4){
	if($_insert_config[4] == '_date'){
		if($_insert_config[2] == ''){
			$pdo_sql = "INSERT INTO ".$_insert_config[1]." (".$_insert_config[1]."_name, ".$_insert_config[1]."_date, sort) VALUES (?, NOW(), ?)";
			$pdo->prepare($pdo_sql)->execute([$_insert_value, $_insert_sort]);
		}else{
			$pdo_sql = "INSERT INTO ".$_insert_config[1]." (".$_insert_config[1]."_name, kod_".$_insert_config[2].", ".$_insert_config[1]."_date, sort) VALUES (?, ?, NOW(), ?)";
			$pdo->prepare($pdo_sql)->execute([$_insert_value, $_insert_config[3], $_insert_sort]);
		}
	}
}else{
	if($_insert_config[2] == ''){
		$pdo_sql = "INSERT INTO ".$_insert_config[1]." (".$_insert_config[1]."_name, sort) VALUES (?, ?)";
		$pdo->prepare($pdo_sql)->execute([$_insert_value, $_insert_sort]);
	}else{
		$pdo_sql = "INSERT INTO ".$_insert_config[1]." (".$_insert_config[1]."_name, kod_".$_insert_config[2].", sort) VALUES (?, ?, ?)";
		$pdo->prepare($pdo_sql)->execute([$_insert_value, $_insert_config[3], $_insert_sort]);
	}
}

$pdo_query = $pdo->prepare("SELECT MAX(".$_insert_config[1].".kod_".$_insert_config[1].") FROM ".$_insert_config[1]."");
$pdo_query->execute();
while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){
	echo reset($pdo_row);
}

?>