<?php

include "dsn.php";

$_select_prefix = $_POST['_select_prefix'];
$_select_sort = $_POST['_select_sort'];
$_select_parent_prefix = $_POST['_select_parent_prefix'];
$_select_parent_kod = $_POST['_select_parent_kod'];
$_select_sql = '';

$_select_count = '';

$pdo_query = $pdo->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '".$_select_prefix."';");
$pdo_query->execute([]);
while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){
	$_select_count = reset($pdo_row);
	echo $_select_count.'{divide}';
}

if($_select_prefix == ''){
	$pdo_query = $pdo->prepare("SELECT * FROM contact");
	$pdo_query->execute([]);
	while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){
		print join('#', $pdo_row).'#';
	}
}else{
	if($_select_parent_prefix == ''){
		if($_select_sort == ''){
			$_select_sql = "SELECT * FROM ".$_select_prefix." ORDER BY ".$_select_prefix.".sort";
		}elseif($_select_sort == 'name'){
			$_select_sql = "SELECT * FROM ".$_select_prefix." ORDER BY ".$_select_prefix.".".$_select_prefix."_name";
		}

		$pdo_query = $pdo->prepare($_select_sql);
		$pdo_query->execute();
		while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){
			print join('#', $pdo_row).'#';
		} 
	}else{
		if($_select_sort == ''){
			$_select_sql = "SELECT * FROM ".$_select_prefix." WHERE (((".$_select_prefix.".kod_".$_select_parent_prefix.")=?)) ORDER BY ".$_select_prefix.".sort";
		}elseif($_select_sort == 'name'){
			$_select_sql = "SELECT * FROM ".$_select_prefix." WHERE (((".$_select_prefix.".kod_".$_select_parent_prefix.")=?)) ORDER BY ".$_select_prefix.".".$_select_prefix."_name";
		}

		$pdo_query = $pdo->prepare($_select_sql);
		$pdo_query->execute([$_select_parent_kod]);
		while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){
			print join('#', $pdo_row).'#';
		} 	
	}
}

?>