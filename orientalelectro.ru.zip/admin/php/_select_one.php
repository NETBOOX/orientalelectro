<?php

include "dsn.php";

$_select_prefix = $_POST['_select_prefix'];
$_select_kod = $_POST['_select_kod'];

$pdo_query = $pdo->prepare("SELECT * FROM ".$_select_prefix." WHERE (((".$_select_prefix.".kod_".$_select_prefix.")=?))");
$pdo_query->execute([$_select_kod]);
while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){
	print join('#', $pdo_row).'#';
} 

?>