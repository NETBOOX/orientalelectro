<?php

include "dsn.php";

$_select_option_config = explode("#", $_POST['_select_option_config']);

$html_value = '<option value="0">-</option>';

$pdo_query = $pdo->prepare("SELECT * FROM ".$_select_option_config[0]." ORDER BY ".$_select_option_config[0].".sort");
$pdo_query->execute();
while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){
	if($_select_option_config[2] == $pdo_row['kod_'.$_select_option_config[0]]){
		$html_value .= '<option value="'.$pdo_row['kod_'.$_select_option_config[0]].'" selected>'.$pdo_row[$_select_option_config[0].'_name'].'</option>';
	}else{
		$html_value .= '<option value="'.$pdo_row['kod_'.$_select_option_config[0]].'">'.$pdo_row[$_select_option_config[0].'_name'].'</option>';	
	}
}

echo $html_value;

?>