<?php

include "dsn.php";

$_sort = $_POST['_sort'];
$_prefix = $_POST['_prefix'];

$_sort_m = explode(",", $_sort);
$_sort_reg = 0;
$_sort_id = '';
$_sort_kod = '';

foreach($_sort_m as $_sort_value){
	if($_sort_reg == 0){
		$_sort_id = $_sort_value;
		$_sort_reg = 1;   	
	}else{
		$_sort_kod = $_sort_value;
		$pdo_sql = "UPDATE ".$_prefix." SET sort=? WHERE (((".$_prefix.".kod_".$_prefix.")=?))";
		$pdo->prepare($pdo_sql)->execute([$_sort_id, $_sort_kod]);
		$_sort_reg = 0; 
	}
}

?>