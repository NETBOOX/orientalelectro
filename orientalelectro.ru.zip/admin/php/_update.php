<?php

include "dsn.php";

$_update_prefix = $_POST['_update_prefix'];
$_update_kod = $_POST['_update_kod'];
$_update_field = explode("#", base64_decode($_POST['_update_field']));
$_update_value = explode("#", base64_decode($_POST['_update_value']));

for($i = 0; $i < COUNT($_update_field); $i++){
	if($_update_field[$i] == '_geo'){

		$geo_api_key = '2509af1f-2d31-47ec-b526-442aedf65a4c';
		$geo_adres = 'Россия '.$_update_value[$i];
		$geo_coord = "";
		$geo_coord1 = "";
		$geo_coord2 = "";
		$geo_info = file_get_contents('https://geocode-maps.yandex.ru/1.x?format=json&geocode='.urlencode($geo_adres).'&apikey='.$geo_api_key);
		$geo_info = json_decode($geo_info, true);
		$geo_coord = explode(" ", $geo_info["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]["Point"]["pos"]);
		$geo_coord1 = $geo_coord[0];
		$geo_coord2 = $geo_coord[1];

		$pdo_sql = "UPDATE ".$_update_prefix." SET ".$_update_prefix."_coord1=?, ".$_update_prefix."_coord2=? WHERE (((".$_update_prefix.".kod_".$_update_prefix.")=?))";
		$pdo->prepare($pdo_sql)->execute([$geo_coord1, $geo_coord2, $_update_kod]);

	}else{
		$pdo_sql = "UPDATE ".$_update_prefix." SET ".$_update_field[$i]."=? WHERE (((".$_update_prefix.".kod_".$_update_prefix.")=?))";
		$pdo->prepare($pdo_sql)->execute([$_update_value[$i], $_update_kod]);
	}
}

?>