<?php

include "dsn.php";

$kod_cat = $_POST['kod_cat'];
$kod_reg = $_POST['kod_reg'];

$pdo_sql = "UPDATE cat SET disable=? WHERE (((cat.kod_cat)=?))";
$pdo->prepare($pdo_sql)->execute([$kod_reg, $kod_cat]);

?>