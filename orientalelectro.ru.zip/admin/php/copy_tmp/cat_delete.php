<?php

include "dsn.php";

$kod_cat = $_POST['kod_cat'];

if(file_exists('../../files/upload/'.$kod_cat.'/')){
	removeDirectory('../../files/upload/'.$kod_cat.'/');
}

$pdo_sql = 'DELETE FROM cat WHERE kod_cat=?';
$pdo->prepare($pdo_sql)->execute([$kod_cat]);

function removeDirectory($dir) {
	if ($objs = glob($dir."/*")) {
	   foreach($objs as $obj) {
	     is_dir($obj) ? removeDirectory($obj) : unlink($obj);
	   }
	}
	rmdir($dir);
}

?>
