<?php

$photo_file = $_POST['news_file'];
$photo_file = '../'.$photo_file;

if(file_exists($photo_file)){
   unlink($photo_file);
}

?>