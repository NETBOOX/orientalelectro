<?php

$folder_photo = $_POST['folder_photo'];
$dir = '../../files/upload/'.$folder_photo.'/';

$result = array();
$cdir = scandir($dir); 
foreach ($cdir as $value) {
    if (!in_array($value,array(".", "..")) 
        && !is_dir($dir . DIRECTORY_SEPARATOR . $value)){

        $mystring = $value;
        $findme   = 'mini';
        $pos = strpos($mystring, $findme);
        if($pos === false){
            $result[] = $value;
        }
     }
} 
foreach ($result as &$result_value) {
    echo '../files/upload/'.$folder_photo.'/'.$result_value.'#';
}

?>