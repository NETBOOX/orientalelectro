<?php

$kod_cat = $_POST['cat_file_name'];
$cat_file_name = generatePassword();

if(!is_dir('../../files/upload/')){ 
	mkdir('../../files/upload/');   
}

if(!is_dir('../../files/upload/'.$kod_cat.'/')){ 
	mkdir('../../files/upload/'.$kod_cat.'/');   
}

$path = $_FILES['cat_file']['name'];
$uploadedFile =  '../../files/upload/'.$kod_cat.'/'.$cat_file_name.'.webp';

if(file_exists($uploadedFile)){
   unlink($uploadedFile);
}

move_uploaded_file($_FILES["cat_file"]["tmp_name"],$uploadedFile);

$res = '<script type="text/javascript">';
$res .= 'window.parent.cat_file_finish();';
$res .= "</script>";
echo $res;

function generatePassword($length = 8){
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $count = mb_strlen($chars);
    for ($i = 0, $result = ''; $i < $length; $i++) {
        $index = rand(0, $count - 1);
        $result .= mb_substr($chars, $index, 1);
    }
    return $result;
}


?>