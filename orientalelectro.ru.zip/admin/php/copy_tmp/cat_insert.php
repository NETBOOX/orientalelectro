﻿<?php

include "dsn.php";

$cat = $_POST['cat'];
$sort = $_POST['sort'];

$kod_cat_max = '';

$pdo_sql = "INSERT INTO cat (cat_name, sort) VALUES (?,?)";
$pdo->prepare($pdo_sql)->execute([$cat, $sort]);

$pdo_query = $pdo->prepare("SELECT MAX(cat.kod_cat) FROM cat");
$pdo_query->execute();
while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){
	$kod_cat_max = reset($pdo_row);
}

echo $kod_cat_max;

?>