<?php

include "dsn.php";

$pdo_query = $pdo->prepare("SELECT cat.kod_cat, cat.cat_name, cat.sort FROM cat ORDER BY cat.sort");
$pdo_query->execute();
while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){
	print join('#', $pdo_row).'#';
} 

?>