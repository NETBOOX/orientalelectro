<?php

include "dsn.php";

$kod_cat = $_POST['kod_cat'];

$pdo_query = $pdo->prepare("SELECT * FROM cat WHERE (((cat.kod_cat)=?));");
$pdo_query->execute([$kod_cat]);
while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){
	print join('#', $pdo_row).'#';
} 

?>