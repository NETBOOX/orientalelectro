<?php

include "dsn.php";

$kod_cat = $_POST['kod_cat'];
$cat_u = explode("#", base64_decode($_POST['cat_update_text']));

$pdo_sql = "UPDATE cat SET cat_name=?, cat_desc=?, cat_link=? WHERE (((cat.kod_cat)=?))";
$pdo->prepare($pdo_sql)->execute([$cat_u[0], $cat_u[1], $cat_u[2], $kod_cat]);

?>