<?php

include "dsn.php";

$sec = explode(",", $_POST['cat_sort']);
$reg = 0;
$id_cat = '';

foreach($sec as $val){
	if ($reg == 0){
		$id_cat = $val;
		$reg = 1;   	
	}else{
		$pdo_sql = "UPDATE cat SET sort=? WHERE (((cat.kod_cat)=?))";
		$pdo->prepare($pdo_sql)->execute([$id_cat, $val]);
		$reg = 0; 
	}
}

?>