<?php

$dsn_file = explode(",", file_get_contents('../../php/connect.x', true));
$dsn_host = $dsn_file[0];
$dsn_user = $dsn_file[1];
$dsn_pass = $dsn_file[2];
$dsn_db   = $dsn_file[3];

$dsn = "mysql:host=$dsn_host;dbname=$dsn_db;charset=utf8";
$dsn_opt = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];
$pdo = new PDO($dsn, $dsn_user, $dsn_pass, $dsn_opt);

?>