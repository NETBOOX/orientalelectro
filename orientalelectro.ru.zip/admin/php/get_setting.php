<?php

include "dsn.php";

$pdo_query = $pdo->prepare("SELECT setting.".$set_value." FROM setting;");
$pdo_query->execute();
while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){
	echo base64_decode($pdo_row[$set_value]);
} 

?>
