<?php

include "dsn.php";

$pdo_query = $pdo->prepare("SELECT setting.s_name, setting.s_name_desc, setting.s_adres, setting.s_phone1, setting.s_phone2, setting.s_mail, setting.s_time, setting.s_youtube, setting.s_instagram, setting.s_vk, setting.s_facebook, setting.s_map, setting.s_title, setting.s_desc, setting.s_keys, setting.s_ios, setting.s_android, setting.s_color FROM setting;");
$pdo_query->execute([]);
while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){
    print join('#', $pdo_row).'#';
} 

?>