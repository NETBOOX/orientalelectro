<?php

include "dsn.php";

$s_name = $_POST['s_name'];
$s_name_desc = $_POST['s_name_desc'];
$s_adres = $_POST['s_adres'];
$s_phone1 = $_POST['s_phone1'];
$s_phone2 = $_POST['s_phone2'];
$s_mail = $_POST['s_mail'];
$s_time = $_POST['s_time'];
$s_youtube = $_POST['s_youtube'];
$s_instagram = $_POST['s_instagram'];
$s_vk = $_POST['s_vk'];
$s_facebook = $_POST['s_facebook'];
$s_map = $_POST['s_map'];
$s_title = $_POST['s_title'];
$s_desc = $_POST['s_desc'];
$s_keys = $_POST['s_keys'];
$s_ios = $_POST['s_ios'];
$s_android = $_POST['s_android'];
$s_color = $_POST['s_color'];

$pdo_sql = "UPDATE setting SET s_name=?, s_name_desc=?, s_adres=?, s_phone1=?, s_phone2=?, s_mail=?, s_time=?, s_youtube=?, s_instagram=?, s_vk=?, s_facebook=?, s_map=?, s_title=?, s_desc=?, s_keys=?, s_ios=?, s_android=?, s_color=?";
$pdo->prepare($pdo_sql)->execute([$s_name, $s_name_desc, $s_adres, $s_phone1, $s_phone2, $s_mail, $s_time, $s_youtube, $s_instagram, $s_vk, $s_facebook, $s_map, $s_title, $s_desc, $s_keys, $s_ios, $s_android, $s_color]);

?>