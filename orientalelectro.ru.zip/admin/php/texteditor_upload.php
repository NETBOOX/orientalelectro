<?php

if($_FILES['image']['name']){
    if (!$_FILES['image']['error']) {
        $name = md5(rand(100, 200));
        $ext = explode('.', $_FILES['image']['name']);
        $filename = $name . '.' . $ext[1];
        $destination = '../../files/upload/' . $filename;
        $location = $_FILES["image"]["tmp_name"];
        move_uploaded_file($location, $destination);
        echo $_SERVER['SERVER_NAME'].'/files/upload/' . $filename;
    }else{
      echo  $message = 'error upload';
    }
}

?>
