
<?php

include "php/dsn.php";
include "php/SEO/seedPageClass.php";
// require_once "php/_mobile_detect.php";
// $detect = new Mobile_Detect;

function isMobileDevice(){
    return preg_match("/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"]);
}

$detect = '';
if(isMobileDevice() == true){
	$detect = 'mobile';
}

@$main_page = $_GET["page"];
$main_page_cat = '';
$main_page_tires = '';

$page_regim = '';
$page_type = '';
$page_kod = '';
$page_title = '';
$page_date = '';
$page_content = '';

$html_value = '';
$coord_value = '';

$seoObj = new seedPageClass($_GET['page'] ?? '');

if($main_page != ''){
	if(file_exists('page/'.$main_page.'.html')){
		if($main_page == 'delivery-and-payment' || $main_page == 'about' || $main_page == 'catalog'){
			$file_string = '';
			$pattern = '';
			$tag_value = '';
			$tagname = 'h1';

			$file_string = file_get_contents('page/'.$main_page.'.html', true);
			$pattern = "/<$tagname>([\w\W]*?)<\/$tagname>/";
			preg_match($pattern, $file_string, $matches);
			$tag_value = $matches[1];
			$page_title = $tag_value;

			include 'page/header.html';
		}else{
			$file_string = '';
			$pattern = '';
			$tag_value = '';
			$tagname = 'h1';

			$file_string = file_get_contents('page/'.$main_page.'.html', true);
			$pattern = "/<$tagname>([\w\W]*?)<\/$tagname>/";
			preg_match($pattern, $file_string, $matches);
			$tag_value = $matches[1];
			$page_title = $tag_value;

			include 'page/header_pg.html';
		}

		include 'page/'.$main_page.'.html';
	}else{
		include 'page/header_pg.html';
		include 'page/404.html';
	}
}else{
	$page_title = 'Oriental';

	include 'page/header.html';
	include 'page/home.html';
}

include 'page/footer.html';

function translit($str){
	$str = mb_strtolower($str);
	$rus = array('а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ъ', 'ы', 'ь', 'э', 'ю', 'я', ' ');
	$lat = array('a', 'b', 'v', 'g', 'd', 'e', 'e', 'j', 'z', 'i', 'i', 'k', 'l', 'm', 'n', 'o', 'p', 'r', 's', 't', 'u', 'f', 'h', 'c', 'ch', 'sh', 'shch', '', 'y', '', 'e', 'u', 'ya', '_');
	$str = str_replace($rus, $lat, $str);
	return $str;
}
	
?>