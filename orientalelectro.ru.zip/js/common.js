var z_name = [];
var z_art = [];
var z_num = [];

function load_manager(){
    var tovar_cookie = read_сookie('tovar_recent');
    var tovar_cookie_lk = [];

    if(tovar_cookie != null){
        tovar_cookie_lk =  tovar_cookie.split(',');
        for(var i = 0; i < tovar_cookie_lk.length-1; i += 3){
            z_name.push(tovar_cookie_lk[i]);
            z_art.push(tovar_cookie_lk[i+1]);
            z_num.push(tovar_cookie_lk[i+2]);
        }

        add_recent_re();
    }
}
document.addEventListener( "DOMContentLoaded", load_manager, false );

$(document).ready(function(){
    var show = true;
    var countbox = ".benefits__inner";
    $(window).on("scroll load resize", function () {
        if (!show) return false; // Отменяем показ анимации, если она уже была выполнена
        var w_top = $(window).scrollTop(); // Количество пикселей на которое была прокручена страница
        var e_top = $(countbox).offset().top; // Расстояние от блока со счетчиками до верха всего документа
        var w_height = $(window).height(); // Высота окна браузера
        var d_height = $(document).height(); // Высота всего документа
        var e_height = $(countbox).outerHeight(); // Полная высота блока со счетчиками
        if (w_top + 500 >= e_top || w_height + w_top == d_height || e_height + e_top < w_height) {
            $('.benefits__number').css('opacity', '1');
            $('.benefits__number').spincrement({
                thousandSeparator: "",
                duration: 5000
            });
            show = false;
        }
    });
 
});

function load_fin(){
    document.getElementById('i_map_bl').innerHTML = '<script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A9b84d5377a55a8113bc1942bae0a6dc7c3d0a97fce95ca9a9eeec89e70a0aefa&amp;width=100%25&amp;height=400&amp;lang=ru_RU&amp;scroll=true"></script>';
}

function fixed_toggle(){
    $(".fixed_bl_op").toggleClass("active");
    $(".fixed_bl").toggleClass("active");
}

var catm_main_id = '';
var catm_main_kod = '';

function catm_change(catm_change_id_tmp, catm_change_kod_tmp){
    catm_main_id = catm_change_id_tmp;
    catm_main_kod = catm_change_kod_tmp;

    if(catm_change_id_tmp != '0'){
        $(".catm_cl").removeClass("active");
        $("#i_catm" + catm_change_id_tmp).addClass("active");
    }

    document.getElementById('i_catb_out').innerHTML = 'Загрузка...';

    $.ajax({
        type: 'POST',
        url: 'php/tovar_select.php',
        data: {'kod_catm': catm_change_kod_tmp},
        dataType: 'text',
        success: function(text){
            document.getElementById('i_catb').innerHTML = text;
        }
    });     
}

function catm_chan(catm_change_id_tmp, catm_change_kod_tmp){
    catm_main_id = catm_change_id_tmp;
    catm_main_kod = catm_change_kod_tmp;

    if(catm_change_id_tmp != '0'){
        $(".catm_cl").removeClass("active");
        $("#i_catm" + catm_change_id_tmp).addClass("active");
    }

    document.getElementById('i_catb_out').innerHTML = 'Загрузка...';

    $.ajax({
        type: 'POST',
        url: 'php/tovar_select1.php',
        data: {'kod_catm': catm_change_kod_tmp},
        dataType: 'text',
        success: function(text){
            document.getElementById('i_catb').innerHTML = text;
        }
    });     
}

function catb_search_clear(){
    document.getElementById('i_search').value = '';
    document.getElementById('i_catb_out').style.display = 'none';
    document.getElementById('i_top_bl_search_op').style.display = 'none';
}

function catb_search(){
    if(document.getElementById('i_search').value == ''){
        document.getElementById('i_catb_out').style.display = 'none';
        document.getElementById('i_top_bl_search_op').style.display = 'none';

        if(catm_main_id == ''){
            document.getElementById('i_catm0').click();
        }else{
            catm_change(catm_main_id, catm_main_kod);
        }
    }else{
        document.getElementById('i_catb_out').innerHTML = 'Поиск...';
        document.getElementById('i_catb_out').style.display = 'block';
        document.getElementById('i_top_bl_search_op').style.display = 'block';

        $.ajax({
            type: 'POST',
            url: 'php/tovar_search.php',
            data: {'catb_search': document.getElementById('i_search').value},
            dataType: 'text',
            success: function(text){
                document.getElementById('i_catb_out').innerHTML = text;
            }
        });   
    }  
}

function hide_show(){
    $(".hide_cl_link").addClass("active");
    $(".hide_cl").addClass("active");
}

function search_insert(search_insert_text_tmp){
    document.getElementById('i_search').value = search_insert_text_tmp;
    catb_search();
}

// -------------------------------------------------

var z_name_tmp = '';
var z_art_tmp = '';
var z_id_tmp = '';

function add_open1(add_open_name_tmp, add_open_art_tmp){
    z_name_tmp = add_open_name_tmp;
    z_art_tmp = add_open_art_tmp;

    document.getElementById('i_add_count_title1').innerHTML = Base64.decode(add_open_name_tmp) + '<span>' + Base64.decode(add_open_art_tmp) + '</span>';
    document.getElementById('i_add_count_num1').value = '1';
    $(".add_count_op1").addClass("active");
}

function add_close1(){
    $(".add_count_op1").removeClass("active");
}

function add_recent(){
var add_recent_re_count_reg = 0;

    add_close1();

    for(var i = 0; i < z_art.length; i++){
        if(z_art_tmp == z_art[i]){
            z_num[i] = parseInt(z_num[i]) + parseInt(document.getElementById('i_add_count_num1').value);
            add_recent_re_count_reg = 1;
        }
    }  

    if(add_recent_re_count_reg == 0){
        z_name.push(z_name_tmp);
        z_art.push(z_art_tmp);
        z_num.push(parseInt(document.getElementById('i_add_count_num1').value));
    }

    var tovar_cookie = '';
    for(var i = 0; i < z_art.length; i++){
        tovar_cookie += z_name[i] + ',' + z_art[i] + ',' + z_num[i] + ',';
    }  

    write_cookie('tovar_recent', tovar_cookie, '3600');

    add_recent_re();
}

function add_recent_re(){
var add_recent_re_count = 0;

    for(var i = 0; i < z_art.length; i++){
        add_recent_re_count += parseInt(z_num[i]);
    }    

    if(add_recent_re_count == 0){
        document.getElementById('i_recent').innerHTML = '<i class="bi bi-cart"></i>Список покупок';
    }else{
        document.getElementById('i_recent').innerHTML = '<i class="bi bi-cart"></i>Список - ' + add_recent_re_count + ' шт.';
    }
}

// ---------------------------------------------------

function add_open2(add_open_name_tmp, add_open_art_tmp, add_open_num_tmp, add_open_id_tmp){
    z_name_tmp = add_open_name_tmp;
    z_art_tmp = add_open_art_tmp;
    z_id_tmp = add_open_id_tmp;

    document.getElementById('i_add_count_title2').innerHTML = Base64.decode(add_open_name_tmp) + '<span>' + Base64.decode(add_open_art_tmp) + '</span>';

    if(parseInt(document.getElementById('i_y' + add_open_id_tmp).innerText) == 0){
        document.getElementById('i_add_count_num2').value = '1';
    }else{
        document.getElementById('i_add_count_num2').value = parseInt(document.getElementById('i_y' + add_open_id_tmp).innerText);
    }
    
    $(".add_count_op2").addClass("active");
}

function add_close2(){
    $(".add_count_op2").removeClass("active");
}

function add_recent_recount(){
    add_close2();

    for(var i = 0; i < z_art.length; i++){
        if(z_art_tmp == z_art[i]){
            z_num[i] = parseInt(document.getElementById('i_add_count_num2').value);

            try{
                if(document.getElementById('price' + z_id_tmp).innerText != 'Узнать цену'){
                    document.getElementById('price_all' + z_id_tmp).innerText = 'Сумма: ' + number_space((parseFloat(z_num[i]) * parseFloat(document.getElementById('price' + z_id_tmp).innerText.replace(' Руб.',''))).toFixed(2)) + ' руб.';
                }
            }catch(err){
                document.getElementById('price_all' + z_id_tmp).innerText = '';
            }

            try{
                z_num_pg[i] = parseInt(document.getElementById('i_add_count_num2').value);
            }catch(err){
            }
        }
    } 

    var tovar_cookie = '';
    for(var i = 0; i < z_art.length; i++){
        tovar_cookie += z_name[i] + ',' + z_art[i] + ',' + z_num[i] + ',';
    }  

    write_cookie('tovar_recent', tovar_cookie, '3600');

    try{
        document.getElementById('i_y' + z_id_tmp).innerText = document.getElementById('i_add_count_num2').value;
    }catch(err){
    }

    add_recent_re();

    try{
        get_price_recent_all();
    }catch(err){
    }

}

function add_remove(add_remove_art_tmp, add_remove_id_tmp){
    if(z_name.length == 1){
        z_name.length = 0;
        z_art.length = 0;
        z_num.length = 0;

        z_name_pg.length = 0;
        z_art_pg.length = 0;
        z_num_pg.length = 0;        
        z_price_pg.length = 0;        
    }else{
        for(var i = z_art.length; i > 0; i--){
            if(add_remove_art_tmp == z_art[i]){
                z_name.splice(i,1);
                z_art.splice(i,1);
                z_num.splice(i,1);

                z_name_pg.splice(i,1);
                z_art_pg.splice(i,1);
                z_num_pg.splice(i,1);                
                z_price_pg.splice(i,1);                
            }
        }  
    }

    document.getElementById("i_yt" + add_remove_id_tmp).remove();

    var tovar_cookie = '';
    for(var i = 0; i < z_art.length; i++){
        tovar_cookie += z_name[i] + ',' + z_art[i] + ',' + z_num[i] + ',';
    }  

    write_cookie('tovar_recent', tovar_cookie, '3600');
    add_recent_re();

    try{
        get_price_recent_all();
    }catch(err){
    }

}

function get_price(get_price_code_tmp, get_price_id_tmp){
    document.getElementById('price' + get_price_id_tmp).style.background = '#4fac3d';
    document.getElementById('price' + get_price_id_tmp).innerText = '...';

    $.ajax({
        type: 'POST',
        url: 'php/price.php',
        data: {'code': get_price_code_tmp},
        dataType: 'text',
        success: function(text){
            if(!isNaN(parseFloat(text)) && isFinite(text)){
                document.getElementById('price' + get_price_id_tmp).style.background = '#4fac3d';
                document.getElementById('price' + get_price_id_tmp).style.color = '#fff';
                document.getElementById('price' + get_price_id_tmp).style.textDecoration = 'none';
                document.getElementById('price' + get_price_id_tmp).innerText = text + ' Руб.';
            }else{
                document.getElementById('price' + get_price_id_tmp).innerText = 'Не доступно';
            }
        }
    });  
}

function isInteger(num) {
  return (num ^ 0) === num;
}

// function map_load(){
//     document.getElementById('i_map_bl').innerHTML = '<script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A9b84d5377a55a8113bc1942bae0a6dc7c3d0a97fce95ca9a9eeec89e70a0aefa&amp;width=100%25&amp;height=400&amp;lang=ru_RU&amp;scroll=true"></script>';   
// }