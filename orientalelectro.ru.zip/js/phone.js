var items = document.getElementsByClassName('phone_mask');

Array.prototype.forEach.call(items, function(element) {
    var phoneMask = new IMask(element, {
  mask: '+{7} (000) 000-00-00',
  lazy: false
});
});
