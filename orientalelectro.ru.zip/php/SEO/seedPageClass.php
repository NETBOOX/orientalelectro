<?php

/**
 * @copyright Copyright (c) Unique Magic
 * @author Dmitriy Bondarev <uniquemagic@yandex.ru>
 * 
 * Содержит необходимые константы для страниц (title, description, keywords, canonicals)
 * Содержит методы для получения значений SEO
 * Есть привязка к гео в зависимости от города (поддомены)
 * Предоставляет schema.org
 */
class seedPageClass
{
    private const BASE_URL      = 'https://orientalelectro.ru/';
    private const URL_DELIMITER = '/';

    private const SPACE = ' ';

    private const CITY_NAME_MOSCOW = self::SPACE . 'в Москве';
    private const SUBDOMAIN_MOSCOW = '';

    private const SUBDOMAINS_CITIES = [
        self::SUBDOMAIN_MOSCOW => self::CITY_NAME_MOSCOW,
    ];

    // Страницы
    private const HOME     = '';
    private const CATALOG  = 'catalog';
    private const DOSTAVKA = 'delivery-and-payment';
    private const ABOUT    = 'about';
    private const CONTACT  = 'contact';
    private const RECENT   = 'recent';

    // Суффикс всех страниц
    private const PAGE_SUFFIX_DELIMITER = ' | ';
    private const COMPANY_PREFFIX       = 'ООО';
    private const COMPANY_NAME          = 'Ориенталь';
    private const PAGE_SUFFIX           = self::PAGE_SUFFIX_DELIMITER . self::COMPANY_PREFFIX . self::SPACE . self::COMPANY_NAME;
    private const COMPANY_PHONE         = '8 (800) 222-40-07';

    private const PAGES_TITLES = [
        self::HOME     => 'Изделия для электромонтажа, освещение и связь',
        self::CATALOG  => 'Каталог электропродукции',
        self::DOSTAVKA => 'Прием заявок и доставка',
        self::ABOUT    => 'Информация о компании',
        self::CONTACT  => 'Наши контакты',
        self::RECENT   => 'Ваш список покупок',
    ];

    private const PAGES_DESCRIPTIONS = [
        self::HOME     => 'Производство и поставка кабельно-проводниковой продукции и электротоваров по всей территории РФ. Низкие цены и высокое качество материалов. Заказывайте по тел. ' . self::COMPANY_PHONE,
        self::CATALOG  => 'Посмотрите список наших товаров на сайте и заказывайте кабели, высоковольтное и щитовое оборудование, генераторы, инструменты и технику, кабели и провода по низким ценам оптом',
        self::DOSTAVKA => 'Узнайте об особенностях работы компании. Широкий ассортимент и собственная логистическая система, низкие цены и богатый ассортимент электрооборудования',
        self::ABOUT    => 'Предлагаем электротехнические товары по низким ценам. Гарантия стабильности и консультации по выбору продукции. Заказывайте сейчас по тел. ' . self::COMPANY_PHONE,
        self::CONTACT  => 'Наш адрес - Москва, Ленинградский пр-кт, д.80, корп.Г, этаж тех. пом.XII, комн.8, офис 57, почта - info@orientalelectro.ru, получить реквизиты организации',
        self::RECENT   => 'Добавьте товары в корзину и узнайте цену прямо сейчас. Остались вопросы? Введите имя и телефон, и мы свяжемся с Вами по любым вопросам заказа'
    ];

    private const PAGES_KEYWORDS = [
        self::HOME     => 'электромонтаж, освещение, связь, безопасность, системы связи, системы безопасности, кабели, провода, электротовары, продукция, москва, заказ, ориенталь',
        self::CATALOG  => 'продукция, кабели, генераторы, инструменты, провода, освещение, электроустановка, телекоммуникации',
        self::DOSTAVKA => 'доставка, оплата, заявка, электрооборудование, высокое качество, быстрые сроки, ориенталь',
        self::ABOUT    => 'о компании, ориенталь, узнать о компании, низкие цены, в москве, электрооборудование, монтраж',
        self::CONTACT  => 'контакты, организация, адрес, москва, телефон, почта, реквизиты',
        self::RECENT   => 'список покупок, корзина, имя, телефон, поиск товаров'
    ];
    
    private $_pageSlug;
    private $_requestHost;
    private $_subdomain;
    private $_city;

    // принимает slug страницы (в index.php - $_GET['page'])
    public function __construct($pageSlug) {
        $this->_pageSlug    = $pageSlug == '' ? self::HOME : $pageSlug; // считаем, что пустой slug - это home
        $this->_requestHost = $this->_getRequestHost();
        $this->_city        = $this->_getCityFromSubdomain();
    }

    public function getTitle() : string
    {
        return key_exists($this->_pageSlug, self::PAGES_TITLES)
            ? self::PAGES_TITLES[$this->_pageSlug] . $this->_city . self::PAGE_SUFFIX
            : $this->_pageSlug;
    }

    public function getDescription() : string
    {
        return key_exists($this->_pageSlug, self::PAGES_DESCRIPTIONS)
            ? self::PAGES_DESCRIPTIONS[$this->_pageSlug]
            : $this->_pageSlug;
    }

    public function getKeyWords() : string
    {
        return key_exists($this->_pageSlug, self::PAGES_KEYWORDS)
            ? self::PAGES_KEYWORDS[$this->_pageSlug]
            : $this->_pageSlug;
    }

    public function getCanonical() : string
    {
        return $this->_requestHost;
    }

    // @deprecated
    public function getSchemaOrg()
    {
        $schemaOrg = [
            '@context' => 'https://schema.org',
            '@type' => 'Organization',
            'name' => self::COMPANY_PREFFIX . self::SPACE . self::COMPANY_NAME,
            'alternateName' => 'Поставщик электротоваров' . self::SPACE . self::COMPANY_NAME,
            'url' => self::BASE_URL,
            'logo' => self::BASE_URL . 'files/logo.svg',
            'contactPoint' => [
                '@type' => 'ContactPoint',
                'telephone' => self::COMPANY_PHONE,
                'contactType' => 'customer service',
                'contactOption' => 'TollFree',
                'areaServed' => 'RU',
                'availableLanguage' => 'Russian'
            ],
        ];

        return json_encode($schemaOrg, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    }

    private function _getRequestHost() : string
    {
        return (!($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]" . self::URL_DELIMITER . $this->_pageSlug;
    }

    private function _getCityFromSubdomain() : string
    {
        $subdomain = explode('.', "$_SERVER[HTTP_HOST]")[0];
        return key_exists($subdomain, self::SUBDOMAINS_CITIES) 
            ? self::SUBDOMAINS_CITIES[$subdomain]
            : self::CITY_NAME_MOSCOW;
    }
}