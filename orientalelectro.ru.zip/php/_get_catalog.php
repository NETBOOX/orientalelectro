<?php

include "dsn.php";

$html_value = '';
$html_reg = 0;
$html_id = 1;

if($detect == 'mobile'){
	$html_value .= '<div style="color: #fff; margin: 90px 0 0 0;">Выберите категорию</div>';
	$html_value .= '<div class="trian_block"><span></span></div>';
	$html_value .= '<select class="trian_bl" style="color: #fff; margin: 10px 0 0 0;" onchange="catm_change(\'0\',this.options[this.selectedIndex].value);">';
}

$pdo_query = $pdo->prepare("SELECT * FROM pod ORDER BY pod.sort");
$pdo_query->execute();
while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){

		if($detect == 'mobile'){

		}else{
			// if($html_reg == 0){
			// 	$html_value .= '<div id="i_catm'.$html_id.'" class="catm_cl catm_item active" onClick="catm_chan(\''.$html_id.'\',\''.$pdo_row['pod_name'].'\');">';
			// 	$html_reg = 1;
			// }else{
				$html_value .= '<div id="i_catm'.$html_id.'" class="catm_cl catm_item" onClick="catm_chan(\''.$html_id.'\',\''.$pdo_row['pod_name'].'\');">';
			//}
				
				$html_value .= '<div>'.$pdo_row['pod_name'].'</div>';
			$html_value .= '</div>';
		}

	$html_id++;	

}

$pdo_query = $pdo->prepare("SELECT * FROM catm ORDER BY catm.catm_name");
$pdo_query->execute();
while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){

		if($detect == 'mobile'){
			$html_value .= '<option style="color: #333;" value="'.$pdo_row['kod_catm'].'">'.$pdo_row['catm_name'].'</option>';
		}else{
			if($html_reg == 0){
				$html_value .= '<div id="i_catm'.$html_id.'" class="catm_cl catm_item active" onClick="catm_change(\''.$html_id.'\',\''.$pdo_row['kod_catm'].'\');">';
				$html_reg = 1;
			}else{
				$html_value .= '<div id="i_catm'.$html_id.'" class="catm_cl catm_item" onClick="catm_change(\''.$html_id.'\',\''.$pdo_row['kod_catm'].'\');">';
			}
				
				$html_value .= '<div>'.$pdo_row['catm_name'].'</div>';
			$html_value .= '</div>';
		}

	$html_id++;	

}

if($detect == 'mobile'){
	$html_value .= '</select>';
}

echo $html_value;

?>