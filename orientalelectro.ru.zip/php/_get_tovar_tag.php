<?php

include "dsn.php";

$html_value = '';

$pdo_query = $pdo->prepare("SELECT * FROM pod ORDER BY pod.sort");
$pdo_query->execute();
while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){
	$html_value .= '<span onClick="search_insert(\''.$pdo_row['pod_name'].'\');">'.$pdo_row['pod_name'].'</span>';
}

echo $html_value;

?>