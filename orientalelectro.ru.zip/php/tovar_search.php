<?php

include "dsn.php";

$_catb_search = $_POST['catb_search'];

$html_value = '';
$html_value_id = 0;

$pdo_query = $pdo->prepare("SELECT * FROM catb WHERE (((catb.catb_name) Like ?)) ORDER BY catb.catb_name");
$pdo_query->execute(['%'.$_catb_search.'%']);
while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){

	$html_value .= '<div class="catb_item catb_item_se catb_item_search">';
		//$html_value .= '<img src="files/catb/'.$pdo_row['kod_catb'].'.svg">';	
		$html_value .= '<div class="catb_item_name" onClick="get_price(\''.$pdo_row['catb_code'].'\',\''.$html_value_id.'\')">'.$pdo_row['catb_name'].'<span>Артикул: '.$pdo_row['catb_code'].' / Бренд: '.$pdo_row['catb_brand'].' / '.$pdo_row['catb_desc1'].'</span></div>';


		$html_value .= '<div class="m_search_center">';
		$html_value .= '<div id="price'.$html_value_id.'" class="catb_item_order catb_item_order7" onClick="get_price(\''.$pdo_row['catb_code'].'\',\''.$html_value_id.'\')">Узнать цену</div>';
		$html_value .= '<div class="catb_item_order" onClick="add_open1(\''.base64_encode($pdo_row['catb_name']).'\',\''.base64_encode($pdo_row['catb_code']).'\');">В список покупок</div>';
		$html_value .= '</div>';


	$html_value .= '</div>';

	$html_value_id++;

}

echo $html_value;

?>