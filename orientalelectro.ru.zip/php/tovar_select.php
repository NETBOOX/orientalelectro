<?php

include "dsn.php";

require_once "_mobile_detect.php";
$detect = new Mobile_Detect;

$_kod_catm = $_POST['kod_catm'];

$html_value = '';
$html_value_reg = 0;
$html_value_id = 0;

$pdo_query = $pdo->prepare("SELECT * FROM catb WHERE (((catb.kod_catm)=?)) ORDER BY catb.catb_name");
$pdo_query->execute([$_kod_catm]);
while ($pdo_row = $pdo_query->fetch(PDO::FETCH_ASSOC)){

	if($detect == 'mobile'){
		if($html_value_reg < 20){
			$html_value .= '<div class="catb_item">';
				$html_value .= '<div class="catb_item_name" onClick="get_price(\''.$pdo_row['catb_code'].'\',\''.$html_value_id.'\')">'.$pdo_row['catb_name'].'<span>Артикул: '.$pdo_row['catb_code'].' / Бренд: '.$pdo_row['catb_brand'].' / '.$pdo_row['catb_desc1'].'</span></div>';
				$html_value .= '<div id="price'.$html_value_id.'" class="catb_item_order catb_item_order7" onClick="get_price(\''.$pdo_row['catb_code'].'\',\''.$html_value_id.'\')">Узнать цену</div>';
				$html_value .= '<div class="catb_item_order" onClick="add_open1(\''.base64_encode($pdo_row['catb_name']).'\',\''.base64_encode($pdo_row['catb_code']).'\');">В список покупок</div>';				
			$html_value .= '</div>';
		}elseif($html_value_reg == 20){
			$html_value .= '<div class="hide_cl_link" onClick="hide_show();">Показать все товары</div>';
			$html_value .= '<div class="hide_cl">';

			$html_value .= '<div class="catb_item">';
				$html_value .= '<div class="catb_item_name" onClick="get_price(\''.$pdo_row['catb_code'].'\',\''.$html_value_id.'\')">'.$pdo_row['catb_name'].'<span>Артикул: '.$pdo_row['catb_code'].' / Бренд: '.$pdo_row['catb_brand'].' / '.$pdo_row['catb_desc1'].'</span></div>';
				$html_value .= '<div id="price'.$html_value_id.'" class="catb_item_order catb_item_order7" onClick="get_price(\''.$pdo_row['catb_code'].'\',\''.$html_value_id.'\')">Узнать цену</div>';
				$html_value .= '<div class="catb_item_order" onClick="add_open1(\''.base64_encode($pdo_row['catb_name']).'\',\''.base64_encode($pdo_row['catb_code']).'\');">В список покупок</div>';				
			$html_value .= '</div>';		
		}else{
			$html_value .= '<div class="catb_item">';
				$html_value .= '<div class="catb_item_name" onClick="get_price(\''.$pdo_row['catb_code'].'\',\''.$html_value_id.'\')">'.$pdo_row['catb_name'].'<span>Артикул: '.$pdo_row['catb_code'].' / Бренд: '.$pdo_row['catb_brand'].' / '.$pdo_row['catb_desc1'].'</span></div>';
				$html_value .= '<div id="price'.$html_value_id.'" class="catb_item_order catb_item_order7" onClick="get_price(\''.$pdo_row['catb_code'].'\',\''.$html_value_id.'\')">Узнать цену</div>';
				$html_value .= '<div class="catb_item_order" onClick="add_open1(\''.base64_encode($pdo_row['catb_name']).'\',\''.base64_encode($pdo_row['catb_code']).'\');">В список покупок</div>';				
			$html_value .= '</div>';
		}
	}else{
		if($html_value_reg < 20){
			$html_value .= '<div class="catb_item">';
				$html_value .= '<div id="price'.$html_value_id.'" class="catb_item_order catb_item_order7" onClick="get_price(\''.$pdo_row['catb_code'].'\',\''.$html_value_id.'\')">Узнать цену</div>';
				$html_value .= '<div class="catb_item_order" onClick="add_open1(\''.base64_encode($pdo_row['catb_name']).'\',\''.base64_encode($pdo_row['catb_code']).'\');">В список покупок</div>';
				$html_value .= '<div class="catb_item_name" onClick="get_price(\''.$pdo_row['catb_code'].'\',\''.$html_value_id.'\')">'.$pdo_row['catb_name'].'<span>Артикул: '.$pdo_row['catb_code'].' / Бренд: '.$pdo_row['catb_brand'].' / '.$pdo_row['catb_desc1'].'</span></div>';
			$html_value .= '</div>';
		}elseif($html_value_reg == 20){
			$html_value .= '<div class="hide_cl_link" onClick="hide_show();">Показать все товары</div>';
			$html_value .= '<div class="hide_cl">';

			$html_value .= '<div class="catb_item">';
				$html_value .= '<div id="price'.$html_value_id.'" class="catb_item_order catb_item_order7" onClick="get_price(\''.$pdo_row['catb_code'].'\',\''.$html_value_id.'\')">Узнать цену</div>';
				$html_value .= '<div class="catb_item_order" onClick="add_open1(\''.base64_encode($pdo_row['catb_name']).'\',\''.base64_encode($pdo_row['catb_code']).'\');">В список покупок</div>';
				$html_value .= '<div class="catb_item_name" onClick="get_price(\''.$pdo_row['catb_code'].'\',\''.$html_value_id.'\')">'.$pdo_row['catb_name'].'<span>Артикул: '.$pdo_row['catb_code'].' / Бренд: '.$pdo_row['catb_brand'].' / '.$pdo_row['catb_desc1'].'</span></div>';
			$html_value .= '</div>';		
		}else{
			$html_value .= '<div class="catb_item">';
				$html_value .= '<div id="price'.$html_value_id.'" class="catb_item_order catb_item_order7" onClick="get_price(\''.$pdo_row['catb_code'].'\',\''.$html_value_id.'\')">Узнать цену</div>';
				$html_value .= '<div class="catb_item_order" onClick="add_open1(\''.base64_encode($pdo_row['catb_name']).'\',\''.base64_encode($pdo_row['catb_code']).'\');">В список покупок</div>';
				$html_value .= '<div class="catb_item_name" onClick="get_price(\''.$pdo_row['catb_code'].'\',\''.$html_value_id.'\')">'.$pdo_row['catb_name'].'<span>Артикул: '.$pdo_row['catb_code'].' / Бренд: '.$pdo_row['catb_brand'].' / '.$pdo_row['catb_desc1'].'</span></div>';
			$html_value .= '</div>';
		}
	}

	$html_value_reg++;
	$html_value_id++;
	
}

$html_value .= '</div>';

echo $html_value;

?>